Krishna Jewelers Android APK Project

This is an APK-ready Android Studio project.

Included:
- Android WebView wrapper
- Local offline catalogue assets
- 1500 jewellery design entries
- 1500 local HD SVG jewellery images
- Round icon for Krishna Jewelers
- No purchase/cart/checkout/payment/price/free-shipping/security options
- Product text: For price, please contact Krishna Jewelers
- Dark + gold theme and white + gold theme

How to build APK:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The APK will be created under app/build/outputs/apk/debug/app-debug.apk.

Contact number/location are placeholders and can be updated later in assets/www/index.html/app.js.
