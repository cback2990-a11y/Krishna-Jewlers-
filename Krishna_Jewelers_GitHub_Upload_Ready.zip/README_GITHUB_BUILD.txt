KRISHNA JEWELERS APK - GITHUB BUILD STEPS

1) Open github.com and create a new repository.
2) Upload all files/folders from this project ZIP into the repository.
   Important: upload the CONTENTS inside Krishna_Jewelers_Android_Project folder, not the outer folder only.
3) After upload, open the repository.
4) Go to Actions tab.
5) Open "Build Krishna Jewelers APK" workflow.
6) Tap "Run workflow".
7) Wait until the workflow shows a green check mark.
8) Open the completed workflow run.
9) Download artifact: Krishna-Jewelers-debug-apk.
10) Extract the downloaded ZIP and install app-debug.apk on Android.

This debug APK is for testing/installing directly. For Play Store release, create a signed release APK/AAB later.
